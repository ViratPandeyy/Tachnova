# CMS Event Intelligence — TECHNOVA 2026

A simple, responsive information chatbot based on the CMS TECHNOVA 2026 brochure.

## Requirements
- Python 3.10 or newer
- Internet connection for the optional Google Fonts used in the design

## Run on Windows
1. Extract this ZIP.
2. Open the extracted `CMS_Event_Intelligence` folder in VS Code.
3. Open Terminal > New Terminal.
4. Run:

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

5. Open `http://127.0.0.1:5000` in Chrome.

## Project structure

```text
CMS_Event_Intelligence/
├── app.py
├── requirements.txt
├── data/
│   └── technova.json
├── templates/
│   └── index.html
└── static/
    ├── app.js
    └── style.css
```

## How it works
- `technova.json` stores event facts taken from the brochure.
- `app.py` loads the JSON file and matches words in the question to relevant information.
- `index.html` builds the website.
- `style.css` controls the visual design and responsive layout.
- `app.js` sends the question to Flask and displays the answer.

## Important
This first prototype uses rule-based keyword matching. It is not a generative AI model. If the brochure does not confirm an answer, the chatbot directs the user to the help desk.
