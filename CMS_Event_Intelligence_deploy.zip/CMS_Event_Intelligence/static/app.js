const form = document.getElementById("chat-form");
const input = document.getElementById("question");
const messages = document.getElementById("messages");
const category = document.getElementById("category");

function addMessage(text, sender) {
  const wrapper = document.createElement("div");
  wrapper.className = `message ${sender}`;
  const label = document.createElement("span");
  label.className = "message-label";
  label.textContent = sender === "user" ? "YOU" : "ASSISTANT";
  const paragraph = document.createElement("p");
  paragraph.textContent = text;
  wrapper.append(label, paragraph);
  messages.appendChild(wrapper);
  messages.scrollTop = messages.scrollHeight;
}

async function sendQuestion(question) {
  const cleanQuestion = question.trim();
  if (!cleanQuestion) return;
  addMessage(cleanQuestion, "user");
  input.value = "";

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({message: cleanQuestion, category: category.value})
    });
    const data = await response.json();
    addMessage(data.answer, "bot");
  } catch (error) {
    addMessage("The server could not be reached. Check that the Flask app is running.", "bot");
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  sendQuestion(input.value);
});

document.querySelectorAll(".suggestion").forEach((button) => {
  button.addEventListener("click", () => sendQuestion(button.dataset.question));
});
