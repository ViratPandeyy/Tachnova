from flask import Flask, render_template, request, jsonify
import json
import re
import os
from pathlib import Path

app = Flask(__name__)
DATA_FILE = Path(__file__).parent / "data" / "technova.json"

with open(DATA_FILE, "r", encoding="utf-8") as file:
    DATA = json.load(file)

def normalise(text):
    """Convert text to lowercase and remove punctuation for easier matching."""
    return re.sub(r"[^a-z0-9\s]", " ", text.lower()).strip()

def find_event(message):
    cleaned = normalise(message)
    for event in DATA["events"]:
        name = normalise(event["name"])
        short_name = name.replace(" challenge", "").replace(" (balloon bust)", "")
        if name in cleaned or short_name in cleaned:
            return event
    # A few common aliases
    aliases = {
        "quiz": "AI & Robotics Quiz Challenge",
        "robotics quiz": "AI & Robotics Quiz Challenge",
        "boat": "Boat Race (Senior)",
        "chatbot": "Mini Python Chatbot"
    }
    for alias, event_name in aliases.items():
        if alias in cleaned:
            for event in DATA["events"]:
                if normalise(event["name"]) == normalise(event_name):
                    return event
    return None

def answer_question(message, category="all"):
    text = normalise(message)
    meta = DATA["meta"]

    if any(word in text for word in ["hello", "hi", "hey"]):
        return "Hello! I can help you find information about TECHNOVA 2026. Try asking about events, dates, eligibility, venues or rules."

    if any(word in text for word in ["date", "when is technova", "when does technova", "which day"]):
        return f"TECHNOVA 2026 will take place on {meta['dates']} at {meta['host']}."

    if "deadline" in text or "last date" in text or "register" in text or "registration" in text:
        return f"The brochure lists {meta['registration_deadline']} as the registration deadline. This date has passed. Please contact the event help desk for any update."

    if "report" in text or "reporting time" in text or "arrival" in text:
        return f"The reporting time is {meta['reporting_time']}. Individual event slots will be announced by the organising committee."

    if "help desk" in text or "contact" in text or "coordinator" in text or "phone" in text:
        coordinators = "; ".join(meta["technical_coordinators"])
        return f"Help desk: {meta['help_desk']}. Technical coordinators: {coordinators}."

    if "where" in text and ("host" in text or "school" in text or "technova" in text):
        return f"TECHNOVA 2026 is hosted by {meta['host']}."

    event = find_event(message)
    if event:
        if any(word in text for word in ["where", "venue", "location", "place"]):
            return f"{event['name']} will be held at {event['venue']}."
        if any(word in text for word in ["eligible", "class", "who can", "which class"]):
            return f"Eligibility for {event['name']}: {event['eligibility']}."
        if any(word in text for word in ["teacher", "in charge", "coordinator"]):
            return f"The teacher in charge for {event['name']} is {event['teacher']}."
        if any(word in text for word in ["team", "members", "people"]):
            return f"Team information for {event['name']}: {event['team']}."
        return (f"{event['name']} — {event['date']}. {event['details']} "
                f"Venue: {event['venue']} Eligibility: {event['eligibility']}")

    if "schedule" in text or "timetable" in text or "19 november" in text or "20 november" in text:
        lines = []
        for day in DATA["schedule"]:
            lines.append(f"{day['date']}: {', '.join(day['events'])}. Venue: {day['venue']}. Reporting: {day['reporting']}.")
        return "Event schedule: " + " ".join(lines)

    if "rule" in text or "regulation" in text or "equipment" in text:
        return "General rules: " + " ".join(DATA["rules"])

    if "all events" in text or "list events" in text or "competitions" in text:
        names = ", ".join(item["name"] for item in DATA["events"])
        return "The listed competitions are: " + names + "."

    return "I couldn't find a confirmed answer to that in the TECHNOVA brochure. Please check with the event help desk, Mr. Shubham Asthana."

@app.route("/")
def home():
    return render_template("index.html", events=DATA["events"])

@app.route("/api/chat", methods=["POST"])
def chat():
    payload = request.get_json(silent=True) or {}
    message = payload.get("message", "").strip()
    category = payload.get("category", "all")
    if not message:
        return jsonify({"answer": "Please type a question first."})
    return jsonify({"answer": answer_question(message, category)})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
